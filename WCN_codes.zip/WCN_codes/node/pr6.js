const fs = require('fs');
const filePath = 'example.txt';

fs.readFile(filePath, 'utf8', (err, data) => {
  if (err) {
    console.error('Error reading the file:', err);
    return;
  }
  console.log('File contents:');
  console.log(data);
});

console.log("Fetching data from server...");
setTimeout(() => {
        console.log("Fetched data from server");
    }, 1000); 
    setTimeout(() => {
        console.log("Recieved data")
    }, 2000); 


// to run : open terminal/cmd and type the command: node pr6.js    