import React from 'react';

const ProductDetails = () => {
  return (
    <div className="product-details">
      <h2>Boat Airdopes 141</h2>
      <img src="https://www.boat-lifestyle.com/cdn/shop/files/img_1_mob_800x.png?v=1686043098"
      height="180px" width="270px"></img>
      <p>Description:<br/>
        Let the noise of the world drown as you jam to your rhythm with Airdopes 141.<br/> 
        Equipped with 8mm drivers, these dope wireless earbuds make your playlist sound better with crystal clear audio quality and powerful bass.<br/>
        Experience seamless calling and be clearly heard with ENx™ Technology.<br/>
        That is not all, ASAPTM Charge technology empowers you with 75 minutes of playback with just 5 minutes of charging.<br/>
        With IPX4 Sweat and Water Resistance, there's no stopping you from listening to your workout mix while breaking a sweat.<br/> 
        Moreover, its IWPTM Technology and Quick Response Touch Controls ensure you can answer calls and switch music without interrupting your flow.<br/> 
        Go ahead, your perfect audio match is right here.</p>
      <p>Offer Price: ₹1,199<br/>
        Regular price: ₹4,490.00<br/>
        Discount: 73% Off</p>
      <button className="buy-button">Buy Now</button>
    </div>
  );
};

export default ProductDetails;
