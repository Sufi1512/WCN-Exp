import React from 'react';
import './App.css';
import Header from './components/Header';
import ProductDetails from './components/ProductDetails';
import ContactForm from './components/ContactForm';

function App() {
  return (
    <div className="App">
      <Header />
      <ProductDetails />
      <ContactForm />
    </div>
  );
}

export default App;
