const dateButton = document.getElementById('dateButton');
const outputElement = document.getElementById('output');

function displayCurrentDate() {
    const currentDate = new Date();
    outputElement.textContent = `Current date: ${currentDate.toDateString()}`;
}

dateButton.addEventListener('click', displayCurrentDate);

function CheckError(){
    try{  
    var myArray = ["apple", "banana", "cherry", "date"];
    var inputElement = document.getElementById("arrayInput");
    inputElement.value = myArray.join(', '); 
    }
    catch (error) {
        alert("An error occurred: " + error.message);
    }  
}

function ageValidation() {
    var a = document.getElementById("txtAge").value;
    if (a < 18){
     alert("you are not allowed to access this")
    }
   }

const colors = ['red', 'green', 'blue'];
document.getElementById("color").innerHTML=(colors[1]); 

let text = "print string in JavaScript";  
document.getElementById("strdisp").innerHTML = text; 

const currentDate = new Date();
console.log(currentDate);

class Person {
    constructor(name, age) {
      this.name = name;
      this.age = age;
    }
    displayInfo() {
      console.log(`Name: ${this.name}, Age: ${this.age}`);
    }
  }
const person1 = new Person("Rohan", 20);
person1.displayInfo();
  